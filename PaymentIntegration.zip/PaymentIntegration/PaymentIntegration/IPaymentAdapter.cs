public interface IPaymentAdapter
{
    bool ProcessPayment(PaymentDetails paymentDetails);
}
