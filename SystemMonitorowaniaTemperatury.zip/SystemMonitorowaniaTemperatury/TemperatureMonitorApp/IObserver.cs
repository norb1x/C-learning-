namespace TemperatureMonitorApp
{
    public interface ITemperatureObserver
    {
        void Update(int temperature);
    }
}
