public interface IMathOperation
{
    double Calculate(double num1, double num2);
}
