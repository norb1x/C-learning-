public class SubtractionOperation : IMathOperation
{
    public double Calculate(double num1, double num2)
    {
        return num1 - num2;
    }
}
